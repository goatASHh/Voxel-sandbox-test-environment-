# Android ARM64 build (POCO F6)

This project package is configured for an Android ARM64 build intended for the POCO F6.

## What the workflow does

The GitHub Actions workflow at `.github/workflows/android-apk.yml`:
1. Checks out the source.
2. Installs stable Rust and the `aarch64-linux-android` target.
3. Installs the Android SDK environment.
4. Installs `cargo-quad-apk`.
5. Runs a release Android build.
6. Uploads the generated APK as a downloadable workflow artifact.

## How to run it

1. Create a GitHub repository and upload the contents of this project folder.
2. Open the repository's **Actions** tab.
3. Select **Build POCO F6 Android APK**.
4. Choose **Run workflow** (or push to the `main` branch).
5. Wait for the workflow to finish.
6. Open the completed run and download the artifact named `poco-voxel-sandbox-arm64-apk`.
7. Extract the artifact ZIP and install the APK on the POCO F6.

## Important limitations

- This workflow is prepared but has **not been run or verified** in this environment.
- The source itself has not been compiled here. A failed workflow may expose missing Android metadata, dependency issues, or source compile errors that must be fixed.
- The APK is ARM64-targeted; it is not a claim of tested compatibility or performance.
- Do not treat the current Dev9 source as a finished playable game. The first-person walking/collision/jump/cave test area and persistent save/load are not established as complete.
- The workflow only solves the packaging route. It does not finish or validate gameplay.
