# Voxel targeting milestone

## Why the old approach was replaced

The previous editor sampled a ray at fixed 0.18-block intervals and compared it only with the highest terrain block in a column. That could skip narrow targets, could not select individual tree blocks, and had no reliable adjacent placement cell.

## Current approach

`src/voxel_raycast.rs` implements Amanatides-Woo grid traversal. It visits cells in ray order and returns:

- `cell`: the exact world-space voxel hit;
- `previous`: the immediately preceding empty voxel along the ray;
- `face_normal`: the face entered by the ray;
- `block`: the hit material.

The world adapter in `main.rs` maps signed world X/Z coordinates to chunk coordinates with Euclidean division/remainder. This is important for chunks west/north of the origin. Placement uses `previous`; breaking uses `cell`. Bedrock is protected.

## Tests authored

Unit tests cover nearest-hit selection, negative direction/coordinates, reach limits, zero direction, and vertical rays. They are included in the source but have not been executed because the current environment has no Rust toolchain.

## Known limitations

- Only chunks currently present in the small prototype world can be selected.
- The renderer is not yet a complete 3D voxel renderer, so caves/interior walls and arbitrary underground edits are not fully visible.
- The mesh refresh path still rebuilds the prototype area's meshes; it is not yet section-granular.
- The ray begins by checking the starting cell. If the camera starts inside a solid block, the returned hit has a zero face normal and cannot be used for adjacent placement.
