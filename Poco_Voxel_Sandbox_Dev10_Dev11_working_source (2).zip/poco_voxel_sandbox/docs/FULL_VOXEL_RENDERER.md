# Full 3D voxel renderer milestone

## Implemented in source

- Replaced the heightfield-only terrain mesh and separate tree mesh with exposed-face meshing over every voxel in a chunk.
- Underground solids now contribute faces wherever caves or other air spaces expose them.
- Trees, generated terrain and player-edited blocks use the same block data and renderer.
- Adjacent loaded chunks are queried when deciding whether a boundary face is hidden.
- Chunks are split into 16-block-high vertical sections.
- Face-dense sections are split into multiple meshes before the 16-bit index limit is reached.
- Water has a translucent material colour and is meshed as a distinct block.

## Known limitations

- The current prototype still generates and displays a fixed 3x3 chunk area; this is not yet the streaming world system.
- Missing neighbour chunks are treated as air at the outer edge of the loaded area.
- The current water material is a basic translucent voxel surface, not a fluid simulation or reflective water shader.
- Transparent foliage is not yet alpha-cutout textured.
- Mesh rebuilding after an edit still rebuilds the currently resident meshes; incremental section rebuilds are a later optimization.
- No build or device performance result is claimed. This source has not been compiled in the current environment.

## Performance test plan for the POCO F6

Once an APK can be built, test the same seed and camera positions with:
1. Empty/initial scene after warm-up.
2. Surface view with trees.
3. Cave view looking across exposed underground faces.
4. Repeated block placement/removal in one area.
5. Fly mode moving across chunk boundaries.

Record FPS, frame-time stability, memory, device temperature where available, and whether edits cause visible frame spikes. Compare cold-start and warmed-up results. Stop testing if the phone becomes unusually hot, shows thermal warnings, or behaves abnormally.

## Performance-oriented changes

- Neighbour chunk lookup is indexed once per mesh build instead of linearly
  searching the loaded chunk list for every voxel face.
- Biome classification is cached per x/z column rather than recalculated for
  each solid voxel.
- Block edits rebuild only the edited chunk; adjacent chunks are rebuilt only
  when the edit lies on a shared boundary.
- A rolling 300-frame performance overlay is shown by default and toggled with
  the on-screen PERF button (or F3 on a keyboard). It reports instantaneous FPS, average FPS, estimated 1% low, frame time,
  chunk count, mesh count and mesh vertex count.
- Android memory/thermal telemetry is not yet connected. No FPS target or
  performance result is claimed until an actual F6 build is run.
