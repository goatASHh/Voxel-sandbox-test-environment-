# Development milestones

## 0 — Project foundation
- [x] Android-first configuration model
- [x] Separate world data from rendering residency
- [x] Original stable block IDs and basic material catalogue
- [x] Deterministic seeded height/biome terrain prototype
- [x] Initial underground cave field and ocean fill

## 1 — First visible Android prototype
- [ ] Android app shell and Vulkan-capable renderer (wgpu backend)
- [x] Render a small generated terrain area with a first-pass surface mesh
- [x] Touch camera controls and initial creative toolbar
- [x] Grid-traversal voxel raycast with exact hit cell, previous cell, and face normal
- [x] World-coordinate block edits, including chunk-coordinate lookup
- [ ] Full 3D exposed-face chunk meshing (current terrain renderer is still a surface/vegetation hybrid)
- [ ] Rebuild only affected mesh sections after edits
- [ ] Device profiling on POCO F6; no FPS claims before measurement

## 2 — World streaming and building
- [ ] Asynchronous chunk generation queue with cancellation and priorities
- [ ] Resident CPU chunk data separated from GPU mesh residency
- [ ] Configurable full-detail radius and distant terrain LOD
- [ ] Configurable underground detail depth and dig-triggered expansion
- [ ] Cross-chunk edits, lighting propagation, water boundaries
- [ ] Creative inventory and original block texture atlas

## 3 — Persistence and customization
- [ ] Explicit manual save/load and configurable background saving
- [ ] Versioned world format and atomic save checkpoints
- [ ] Reusable block templates; copy all or selected properties
- [ ] Per-world and global block-template libraries
- [ ] X-ray as a view mode that never alters stored block properties

## 4 — Graphics and diagnostics
- [ ] Modular material/shader pipeline
- [ ] Individually adjustable shadows, AO, water, fog, clouds, bloom and AA
- [ ] Day/night and cloud controls
- [ ] Editable low-overhead performance overlay
- [ ] Benchmark each feature on the F6 and record thermal/performance results

## 5 — Optional simulation
- [ ] Mobs only after the user approves the core building experience

\n## Milestone 3 — flight and vegetation\n- Added free-flight mode toggle (`F`) and mobile-friendly on-screen FLY/+/- controls.\n- Added keyboard movement, vertical flight, and temporary speed boost.\n- Added deterministic oak/pine tree placement with biome-dependent density.\n- Added separate foliage meshing to prevent tree canopy height from corrupting the terrain heightfield mesh.\n- Not yet device-tested; the next build must validate touch input, camera behavior, mesh seams, and compile correctness.\n\n## Milestone 4 — phone-first flight controls\n- Replaced WASD-dependent mobile flight with a virtual joystick, right-side look gesture, and hold-to-rise/descend buttons.\n- Uses Macroquad native multi-touch IDs so movement/look/altitude can be used simultaneously.\n- Disabled touch-to-mouse emulation to prevent one finger from triggering both input systems.\n- Keyboard controls remain only as a desktop fallback. Device testing remains required.\n

## Full voxel renderer milestone

See `FULL_VOXEL_RENDERER.md`. This source milestone must be compiled and checked before it is treated as validated.
