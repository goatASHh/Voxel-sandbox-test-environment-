# Architecture

## Core separation
1. **Persistent world data** — authoritative block IDs, block-template IDs, generated terrain seed, and player edits.
2. **Resident data** — chunk/subchunk data currently held in RAM.
3. **Simulation** — entities, collision, lighting propagation, fluids, and other active logic.
4. **Mesh cache** — CPU-generated geometry for visible chunk sections.
5. **GPU residency** — vertex/index buffers and textures uploaded to the GPU.
6. **Rendering** — only visible geometry is submitted for drawing.

A chunk can be loaded but not meshed or rendered. It can also have saved data without being resident.

## Streaming rules
- Use a small high-detail region around the player.
- Keep a configurable load radius for neighbouring chunk data, without automatically building full meshes.
- Build meshes only for visible/needed sections.
- Use a configurable detailed depth below the surface (initial default: 5 blocks).
- When digging, expand the active detailed region by a configurable amount (initial default: 2 blocks).
- Cave detail is generated or loaded on demand near the player or when the player interacts with a cave entrance/section.
- Preserve world data outside active regions; never delete it just because it is not rendered.
- Distant terrain may use LOD, independently configurable for distance and quality. LOD must preserve silhouettes and should be disableable.

## Rendering and shaders
- Vulkan-capable renderer, with wgpu selecting Vulkan on supported Android devices.
- Use GPU instancing/merged chunk meshes and texture atlases where beneficial.
- Shader effects are separate toggles: shadows, AO, water reflections, bloom, fog, cloud lighting, anti-aliasing.
- Provide per-effect quality settings and live changes where safe.
- Shader quality must not be tied to terrain LOD quality.
- Include a safe fallback path if a device driver lacks a feature.

## Simulation toggles
- Mobs default off; configurable spawn density and simulation distance.
- Day/night cycle can be disabled; time of day remains manually selectable.
- Clouds can be disabled and have independent density, speed, altitude, quality, and shadow controls.

## Saving
- Background saving defaults off, as requested.
- Manual save always available.
- Optional incremental background save and save-on-exit.
- Use atomic writes/checkpoints to reduce corruption risk.

## Implemented CPU prototype

`src/block.rs` defines stable block IDs and basic material traits. `src/chunk.rs` stores a 16 × 128 × 16 voxel column volume in a compact `u16` array. This CPU data is intentionally independent of GPU meshes. `src/terrain.rs` provides seeded deterministic terrain, coarse biome selection, layered surfaces, water fill, and an initial 3D cave field. The generator can produce chunks at negative coordinates as well as positive coordinates.

This first terrain generator is a foundation, not final world generation. Biome transitions, river carving, vegetation/structure placement, cave connectivity, lighting, and border-aware meshing remain future work.
