# Creative building interaction milestone

## Implemented in source
- Centre-screen reticle and short-range surface ray query.
- Five starter creative materials: meadow grass, loam, basalt stone, pale sand,
  and oak log.
- BREAK removes the visible terrain-surface block while protecting bedrock.
- PLACE adds the selected material above the visible terrain surface when the
  destination is replaceable.
- CPU-side chunk data remains authoritative; GPU surface meshes are rebuilt
  after edits.
- Surface-height queries ignore generated tree trunks and foliage, preventing
  a tree canopy from being mistaken for the ground surface.
- Adjacent loaded chunks are consulted for edge heights when rebuilding meshes.

## Deliberate limitations
- Targeting is limited to the visible ground surface. Arbitrary 3D voxel
  targeting, cave-wall editing, and tree-block editing are not implemented.
- The world remains a fixed 3x3 generated area.
- Edits are not yet saved or restored.
- No compile, Android package build, emulator run, or POCO F6 device test has
  been performed. Treat this as source progress only, not a verified build.

## Next engineering steps
1. Replace the surface-only query with a voxel ray traversal that can hit any
   exposed block face.
2. Add persistent edit storage and world save/load.
3. Add a larger inventory, hotbar selection, and block variants.
4. Add chunk streaming and robust cross-chunk voxel meshing before expanding
   the editable world.
