# Renderer milestone 3 — chunk-edge terrain continuity and thumb-anchored controls

This source milestone fixes two issues in the previous prototype:

- Terrain side-face generation now samples the adjacent column in world coordinates even when that neighbour belongs to another chunk. Chunk boundaries therefore follow the same generated height profile as the terrain inside each chunk, instead of treating every outside neighbour as sea-floor height.
- The left movement joystick now anchors at the point where the thumb first touches the lower-left movement area. This avoids requiring the player to reach one fixed joystick location and makes the control easier to use across different phone screen sizes.

## Current controls
- Phone: tap `FLY`; touch and drag in the lower-left area to move; drag on the right side to look; hold `UP` or `DOWN` to change altitude.
- Desktop fallback: `F` toggles flight; `W/A/S/D` move; `Space` rises; `Left Shift` descends; `Left Ctrl` temporarily increases speed.

## Verification status
- Source changes are in place.
- No Rust/Android toolchain is available in this workspace, so this milestone has **not** been compiled, run, or tested on the POCO F6.
- The prototype still has a fixed 3x3 chunk area, no block placement/removal, no save/load UI, and no final settings/menu system.
- Tree mesh visibility at chunk borders, GPU behavior, touch feel, frame pacing, and thermals remain unverified on-device.

This is a development source milestone, not a finished game or APK.
