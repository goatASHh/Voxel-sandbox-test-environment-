# Dev10 / Dev11 reconstruction status

This is an in-progress reconstruction from the uploaded Dev7 source archive. It is not yet a verified APK.

## Implemented in this working source revision
- First-person camera with mouse-drag / right-thumb look.
- Keyboard and touch movement, sprint, jump, gravity, ground detection, basic horizontal AABB-style collision and ceiling checks.
- Creative flight remains available with `F` and touch UP/DOWN controls.
- Touchscreen SAVE and LOAD controls plus desktop `F5` / `F9` shortcuts.
- Versioned JSON world-save schema, stable block IDs, FNV-1a integrity check, strict chunk-data validation, temporary-file write and previous-save backup fallback.
- Existing voxel editing and neighbouring-chunk remeshing retained.
- Android workflow now explicitly installs Android 35 and NDK 27.2.12479018 before building.

## Still required before calling Dev10 / Dev11 complete
- Compile and resolve any Rust or Android packaging errors through GitHub Actions.
- Validate Android save-file storage location and persistence across app restarts on device.
- Add save/load UI feedback that remains visible when the performance overlay is hidden.
- Add step-up movement, more complete collision edge cases, and automated collision tests.
- Test chunk-edge edits, cave passage/headroom and interrupted-save recovery with automated fixtures.
- Test on POCO F6 only after a successful APK artifact exists.

## Current controls
- Move: WASD / left touchscreen joystick
- Look: drag mouse / right touchscreen area
- Jump: Space / touchscreen JUMP
- Sprint: Left Shift / touchscreen RUN
- Flight toggle: F / FLY button; UP/DOWN touch controls while flying
- Break/place: Q/E or right/middle mouse; touchscreen BREAK/PLACE
- Select block: 1-5 or touchscreen material bar
- Save/load: F5/F9 or touchscreen SAVE/LOAD

Background saving remains disabled; saving is manual and synchronous.
