# POCO Voxel Sandbox — development source

An original Android-first creative voxel sandbox. It does not include Minecraft code, textures, or proprietary assets.

## Current milestones

1. **World-data prototype:** seeded procedural terrain, biome selection, layered surfaces, ocean fill, basic cave field, stable block IDs, and chunk storage.
2. **First renderer prototype:** Macroquad 3D camera, chunk surface meshes, exposed cliff faces, orbit/zoom input, and a basic FPS display.
3. **Flight + vegetation prototype:** keyboard flight toggle (F), WASD movement, Space/Shift vertical movement, Ctrl speed boost, touch-friendly FLY toggle and rise/descend buttons, deterministic biome-aware oak/pine tree placement, and a separate foliage mesh so trees do not become fake terrain columns.
4. **Terrain continuity + touch refinement:** side faces sample neighbouring world columns across chunk boundaries, and the movement joystick anchors at the player's initial thumb touch rather than a fixed screen point.

This is still **source code, not a verified Android APK**. The renderer has not yet been compiled or tested on the POCO F6. Android touch mapping, GPU compatibility, frame pacing, and thermals must be tested on the actual device.

## Desktop smoke test (if a Rust desktop target is available)

```sh
cargo test
cargo run
```

## Android status

Macroquad is being used for the first visible prototype because it provides a comparatively lightweight route to an Android-capable renderer. Android SDK/NDK setup, target configuration, packaging, installation, and POCO F6 validation are still required. The final renderer may evolve as device tests reveal driver/performance constraints.

## Design constraints

- Creative building is the core; mobs remain disabled and deferred.
- CPU chunk data is independent of mesh/GPU residency.
- Unseen terrain is never deleted merely because it is not rendered.
- Underground detail depth and dig expansion remain configurable.
- Background saving is opt-in; manual save remains a first-class option.
- Graphics effects are individually configurable, not locked into two presets.
- Original materials and textures will be created for this project.

See `docs/ARCHITECTURE.md`, `docs/BUILD_PLAN.md`, and `docs/RENDERER_MILESTONE.md`.

## Flight controls (prototype)
- Phone: tap `FLY` to toggle; drag the left virtual joystick to move; drag on the right side to look; hold `UP` or `DOWN` to change altitude. These are independent native touch points, so movement, looking and altitude can be combined with multiple fingers.
- Desktop fallback: `F` toggles flight; `W/A/S/D` move; `Space` rises; `Left Shift` descends; `Left Ctrl` temporarily increases speed.
- This is an early control prototype; touch behavior and camera feel must be verified on the POCO F6.

## World-generation direction
The current generator now places deterministic oak-like and pine-like trees using world-coordinate placement, so generating chunks in a different order does not change where trees belong. Forests have higher tree density than meadows and wetlands. This is an initial vegetation pass, not yet a full biome/ecology system. Next generation layers should add river networks, coast shaping, temperature/moisture regions, more tree silhouettes, rocks, flowers, and cave entrances without making chunk generation too expensive.

## Creative surface editing milestone

The current prototype now has a first interactive building pass. Aim the centre
reticle at a visible ground column, choose one of five starter materials, then
use BREAK or PLACE. BREAK removes the visible top terrain block (bedrock is
protected); PLACE adds the selected block directly above the surface. Chunk
surface meshes are rebuilt after an edit so neighbouring chunk edges use the
updated surface heights.

This is deliberately a first pass, not the final voxel interaction system:
selection currently targets terrain surfaces rather than arbitrary cave walls
or individual tree blocks, the world is still a fixed 3x3 demonstration area,
and edits are not yet persisted to disk. The code has not been compiled or
verified on Android in this workspace.


## Development milestone 7 — precise voxel targeting

The creative interaction layer now uses grid-based DDA ray traversal instead of fixed-distance samples against the terrain heightfield. A hit records the exact world voxel, the adjacent cell on the approach side, and the entered face normal. Block edits resolve world coordinates to chunk-local coordinates, so the same edit path works across negative coordinates and chunk boundaries.

This is a source milestone, not a verified Android build. The current renderer still draws a heightfield-style terrain surface plus separate tree meshes; full cave/interior voxel rendering and efficient section-level mesh rebuilds remain outstanding.


The current source milestone replaces the earlier surface-only renderer with full exposed-face voxel meshing. See `docs/FULL_VOXEL_RENDERER.md` for scope and unverified limitations.


The current renderer milestone includes indexed neighbour lookups, per-column biome caching, boundary-aware edit remeshing, and a rolling performance overlay (F3). See `docs/FULL_VOXEL_RENDERER.md` for limits and test guidance.


## Android ARM64 build

See [ANDROID_BUILD.md](ANDROID_BUILD.md) for the GitHub Actions APK build process. The workflow is prepared but has not been run or verified.
